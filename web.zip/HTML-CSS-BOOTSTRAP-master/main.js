var more = document.getElementById("more");
more.onclick = function () {
  alert("This is the only staff we have...");
};
